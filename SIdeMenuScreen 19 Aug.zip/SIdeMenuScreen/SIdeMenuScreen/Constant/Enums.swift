//
//  Enums.swift
//  SIdeMenuScreen
  
enum SideMenuOptions : String,CaseIterable {

    case scanHistory = "Scan History"
    case instrumentInfo = "Instrument info"
    case syncHistory = "Sync history"
    case preferances = "Preferences"
    case seperator = ""
    case help = "Help"
    case requestSupport = "Request support"
    case appTour = "App tour"
    case logout = "Logout"
    
}
